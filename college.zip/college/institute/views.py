from django.shortcuts import get_object_or_404, render
from django.http import Http404
from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from .models import Department,Employee
from django.template import loader
from django.urls import reverse
def index(request):
    latest_department_list = Department.objects.order_by('-pub_date')[:5]
    context = {'latest_department_list': latest_department_list}
    return render(request, 'institute/index.html',context)
def detail(request,department_id):
    department = get_object_or_404(Department, pk=department_id)
    return render(request, 'institute/detail.html', {'department': department})