import datetime
from django.test import TestCase
from django.utils import timezone
from .models import Department
from django.urls import reverse
class DepartmentModelTests(TestCase):
    def test_was_published_recently_with_future_department(self):
        """was_published_recently() returns False for departments whose pub_date is in the future."""
        time = timezone.now() + datetime.timedelta(days=30)
        future_department = Department(pub_date=time)
        self.assertIs(future_department.was_published_recently(), False)
def test_was_published_recently_with_old_department(self):
    """was_published_recently() returns False for departments whose pub_date is older than 1 day."""
    time = timezone.now() - datetime.timedelta(days=1, seconds=1)
    old_department = Department(pub_date=time)
    self.assertIs(old_department.was_published_recently(), False)
def test_was_published_recently_with_recent_department(self):
    """was_published_recently() returns True for departments whose pub_date is within the last day."""
    time = timezone.now() - datetime.timedelta(hours=23, minutes=59, seconds=59)
    recent_department = Department(pub_date=time)
    self.assertIs(recent_department.was_published_recently(), True)
def create_department(department_text, days):
    """
    Create a department with the given `department_text` and published the
    given number of `days` offset to now (negative for departments published
    in the past, positive for departments that have yet to be published).
    """
    time = timezone.now() + datetime.timedelta(days=days)
    return Department.objects.create(department_text=department_text, pub_date=time)
class DepartmentIndexViewTests(TestCase):
    def test_no_departments(self):
        """If no departments exist, an appropriate message is displayed."""
        response = self.client.get(reverse('institute:index'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "No institute are available.")
        self.assertQuerysetEqual(response.context['latest_department_list'], [])
    def test_past_department(self):
        """Departments with a pub_date in the past are displayed on the index page."""
        department = create_department(department_text="Past department.", days=-30)
        response = self.client.get(reverse('institute:index'))
        self.assertQuerysetEqual(response.context['latest_department_list'],[department],)
    def test_future_department(self):
        """Departments with a pub_date in the future aren't displayed on the index page"""
        create_department(department_text="Future department.", days=30)
        response = self.client.get(reverse('institute:index'))
        self.assertContains(response, "No institute are available.")
        self.assertQuerysetEqual(response.context['latest_department_list'], [])
    def test_future_department_and_past_department(self):
        """Even if both past and future departments exist, only past departments are displayed."""
        department = create_department(department_text="Past department.", days=-30)
        create_department(department_text="Future department.", days=30)
        response = self.client.get(reverse('institute:index'))
        self.assertQuerysetEqual(response.context['latest_department_list'],[department],)
    def test_two_past_departments(self):
        """The departments index page may display multiple departments."""
        department1 = create_department(department_text="Past department 1.", days=-30)
        department2 = create_department(department_text="Past department 2.", days=-5)
        response = self.client.get(reverse('institute:index'))
        self.assertQuerysetEqual(response.context['latest_department_list'],[department2, department1],)
class DepartmentDetailViewTests(TestCase):
    def test_future_department(self):
        """The detail view of a department with a pub_date in the future returns a 404 not found."""
        future_department = create_department(department_text='Future department.', days=5)
        url = reverse('institute:detail', args=(future_department.id,))
        response = self.client.get(url)
        self.assertEqual(response.status_code, 404)
    def test_past_department(self):
        """The detail view of a department with a pub_date in the past displays the department's text."""
        past_department = create_department(department_text='Past Department.', days=-5)
        url = reverse('institute:detail', args=(past_department.id,))
        response = self.client.get(url)
        self.assertContains(response, past_department.department_text)