from django.contrib import admin
from .models import Department,Employee
class EmployeeInline(admin.TabularInline):
    model = Employee
    extra = 3
class DepartmentAdmin(admin.ModelAdmin):
    fieldsets = [
        (None,               {'fields': ['department_text']}),
        ('Date information', {'fields': ['pub_date'], 'classes': ['collapse']}),
    ]
    inlines = [EmployeeInline]
    list_display = ('department_text', 'pub_date', 'was_published_recently')
admin.site.register(Department, DepartmentAdmin)