from django.urls import path
from . import views
app_name = 'institute'
urlpatterns = [
    path('', views.index, name='index'),
    path('<int:department_id>/', views.detail, name='detail'),


]